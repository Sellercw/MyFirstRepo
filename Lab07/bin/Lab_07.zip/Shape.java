/**
 * Shape interface
 * @author sellercw
 *
 */
public interface Shape {
	public double getArea();
}
