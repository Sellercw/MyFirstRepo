/**
 * 
 * @author sellercw
 *
 */
public interface Area {
	/**
	 * 
	 * @return returns the area of a shape
	 */
	public double getArea();
}
