/**
 * 
 * @author sellercw
 *
 */
public interface Volume {
	/**
	 * 
	 * @return returns the volume of the shape
	 */
	public double getVolume();
}
