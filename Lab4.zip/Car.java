/**
 * This is my implementation of the Car class
 * @author sellercw
 * @section C
 * @date 2/18/20
 * @version 1.0
 *
 */
public class Car {
	private String owner;
	private String make;
	private String model; 
	private int yearModel;
	private double fuelLevel; 
	private int speed;
	//constructors
	/**
	 * This is the empty constructor
	 */
	public Car() {
		this("", "", "", 0,10,0);
	}
	/**
	 * This constructor takes user input for owner, make, model and yearModel
	 * @param owner name of car owner
	 * @param make make of car
	 * @param model model of car
	 * @param yearModel year of car
	 */
	public Car(String owner, String make, String model, int yearModel) {
		this(owner, make, model, yearModel, 10, 0);
	}
	/**
	 * This constructor takes user input for owner, make, model, yearModel and fuelLevel
	 * @param owner name of car
	 * @param make make of car
	 * @param model model of car
	 * @param yearModel year of car
	 * @param fuelLevel fuel level of car
	 */
	public Car(String owner, String make, String model, int yearModel, double fuelLevel) {
		this(owner,make,model,yearModel,fuelLevel, 0);
	}
	
	/**
	 * This is the full constructor
	 * @param owner owner of car
	 * @param make make of car
	 * @param model model of car
	 * @param yearModel year model of car
	 * @param fuelLevel fuel level of car
	 * @param speed speed of car
	 */
	public Car(String owner, String make, String model, int yearModel, double fuelLevel, int speed) {
		setOwner(owner);
		setMake(make);
		setModel(model);
		setYearModel(yearModel);
		setFuelLevel(fuelLevel);
		setSpeed(speed);
	}
	/**
	 * This is the copy constructor
	 * @param anotherCar copy of a different Car object
	 */
	public Car(Car anotherCar) {
		this(anotherCar.getOwner(), anotherCar.getMake(), anotherCar.getModel(), anotherCar.getYearModel(), anotherCar.getFuelLevel(), anotherCar.getSpeed());
	}
	//getters and setters
	/**
	 * returns the owner of the car.
	 * @return name of owner
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * Sets the name of the owner of the car.
	 * @param owner name of owner
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * returns the make of the car
	 * @return a String
	 */
	public String getMake() {
		return make;
	}
	/**
	 * sets the make of the car
	 * @param make type of car
	 */
	public void setMake(String make) {
		this.make = make;
	}
	/**
	 * returns the model of the car
	 * @return string model
	 */
	public String getModel() {
		return model;
	}
	/**
	 * sets the model of the car
	 * @param model integer value of year 
	 */
	public void setModel(String model) {
		this.model = model;
	}
	/**
	 * returns the year of the car
	 * @return integer of year
	 */
	public int getYearModel() {
		return yearModel;
	}
	/**
	 * sets the year of the car
	 * @param yearModel year car was manufactured
	 */
	public void setYearModel(int yearModel) {
		this.yearModel = yearModel;
	}
	/**
	 * returns the fuel level of the car
	 * @return a value between 0-10
	 */
	public double getFuelLevel() {
		return fuelLevel;
	}
	/**
	 * sets the fuel level of the car, fuel level must be between 0-10
	 * @param fuelLevel how much gas is left in the tank 
	 */
	public void setFuelLevel(double fuelLevel) {
		if(fuelLevel < 0) {
			throw new IllegalArgumentException ("fuel level cannot be below zero.");
		}
		else if(fuelLevel > 10) {
			throw new IllegalArgumentException ("fuel level cannot be above 10.");
		}
		else {
			this.fuelLevel = fuelLevel;
		}
	}
	/**
	 * returns the speed of the car
	 * @return a non negative integer no greater than 200
	 */
	public int getSpeed() {
		return speed;
	}
	/**
	 * sets the speed of the car
	 * @param speed exception thrown when speed less than 0 or greater than 200.
	 */
	public void setSpeed(int speed) {
		if(speed < 0) {
			throw new IllegalArgumentException ("Speed cannot be less than zero.");
		}
		else if(speed > 200) {
			this.speed = 200;
			throw new IllegalArgumentException ("Speed cannot be greater than 200.");
		}
		else {
			this.speed = speed;
		}
	}
	//methods
	/**
	 * increases the car speed by 5 if fuel level is above 0.5 and speed is below 200
	 * @return true if acceleration is successful
	 */
	public boolean accelerate() {
		if(this.getFuelLevel() < 0.5) {
			return false;
		}
		else if(this.getSpeed() > 200) {
			return false; 
		}
		else if((this.getSpeed() > 195) && (this.getSpeed() < 200)) {
			this.setSpeed(200);
			this.setFuelLevel(this.getFuelLevel()-0.5);
			return true;
		}
		else {
			this.setSpeed(this.getSpeed() + 5);
			this.setFuelLevel(this.getFuelLevel() - 0.5);
			return true;
		}
	}
	/**
	 * reduces the cars speed by 5
	 */
	public void brake() {
		if(this.getSpeed() < 5) {
			this.setSpeed(0);
		}
		else
			this.setSpeed(this.getSpeed() - 5);
	}
	/**
	 * returns true if the gas tank is less than 0.5.
	 * @return true of false. 
	 */
	public boolean isGasTankEmpty() {
		return (this.getFuelLevel() < 0.5);
	}
	/**
	 * returns true if the names of two car owners are the same.
	 * @param car
	 * @return boolean true or false.
	 */
	public boolean sameOwner(Car car) {
		return(this.getOwner().equals(car.getOwner()));
	}
	/**
	 * checks to see if one car is the same as the other
	 * @param car Car object
	 * @return true if make, model and yearModel are the same in both Car objects
	 */
	public boolean equals(Car car) {
		return((this.getMake().equals(car.getMake())) && (this.getModel().equals(car.getModel())) && (this.getYearModel() == car.getYearModel()));
	}
	/**
	 * This is my toString method
	 */
	public String toString() {
		return ("Owner: " + this.getOwner() + ", Make: " + this.getMake() + ", Model: " + this.getModel() + ", Year: " + this.getYearModel() + ", Speed: " + this.getSpeed() + ", Fuel Level: " + this.getFuelLevel());
	}
}
