
public class CarDriver {

	public static void main(String[] args) {
		//test the constructors
		System.out.println("-----------------Testing Constructors");
		Car c1 = new Car();
		System.out.println(c1.toString());
		Car c2 = new Car("Colin", "Honda", "Accord", 2004);
		System.out.println(c2.toString());
		Car c3 = new Car("Colin", "Honda", "Accord", 2004, 6);
		System.out.println(c3.toString());
		Car c4 = new Car("Colin", "Honda", "Accord", 2004, 6, 160);
		System.out.println(c4.toString());
		Car c5 = new Car(c4);
		System.out.println(c5.toString());
		//test get functions
		System.out.println("-----------------Testing Getters");
		System.out.println(c5.getOwner());
		System.out.println(c5.getMake());
		System.out.println(c5.getModel());
		System.out.println(c5.getYearModel());
		System.out.println(c5.getFuelLevel());
		System.out.println(c5.getSpeed());
		//test setters
		System.out.println("-----------------Testing Setters");
		c5.setOwner("John");
		c5.setMake("Ford");
		c5.setModel("Fusion");
		c5.setYearModel(2019);
		c5.setSpeed(120);
		c5.setFuelLevel(4);
		System.out.println(c5.toString());
		//test the limit values
		//Un-comment the below two lines to see if less than zero case works
//		c5.setSpeed(-100);
//		System.out.println(c5.toString());
		//un-comment the below two lines to see if greater than 200  case works
//		c5.setSpeed(201);
//		System.out.println(c5.toString());
		
		//check methods
		System.out.println("-----------------Testing Acceleration");
		c5.setFuelLevel(10);
		c5.setSpeed(0);
		System.out.println("Speed and fuel okay : "+ c5.accelerate());
		c5.setSpeed(199);
		System.out.println("Speed between 195-200: " + c5.accelerate() + "Speed: " + c5.getSpeed());
		c5.setSpeed(0);
		c5.setFuelLevel(0.4);
		System.out.println("Fuel low: " + c5.accelerate());
		System.out.println("-----------------Testing brake");
		c5.setSpeed(100);
		c5.brake();
		System.out.println("Should be 95: " + c5.getSpeed());
		c5.setSpeed(2);
		c5.brake();
		System.out.println("Should be 0: " + c5.getSpeed());
		System.out.println("-----------------Testing fuelLevel");
		c5.setFuelLevel(0.5);
		System.out.println("Should be false: " + c5.isGasTankEmpty());
		c5.setFuelLevel(0.4);
		System.out.println("Should be true: " + c5.isGasTankEmpty());
		System.out.println("-----------------Testing sameOwner");
		c5.setOwner("Colin");
		c4.setOwner("Colin");
		System.out.println("Should be true: " + c4.sameOwner(c5));
		c4.setOwner("not Colin");
		System.out.println("Should be false: " + c4.sameOwner(c5));
		System.out.println("-----------------Testing equals");
		Car c6 = new Car(c5);
		System.out.println("Should be true : "+ c6.equals(c5));
		c6.setOwner("Dave");
		System.out.println("Should be true: " + c6.equals(c5));
		c6.setOwner(c5.getOwner());
		c6.setMake("test");
		System.out.println("Should be false: " + c6.equals(c5));
		c6.setMake(c5.getMake());
		c6.setYearModel(1000);
		System.out.println("Should be false: " + c6.equals(c5));
		c6.setYearModel(c5.getYearModel());
		c6.setSpeed(5);
		System.out.println("Should be true: " + c6.equals(c5));
	}

}
